# Floating Pedestal Button — Integration Guide

## Overview

The `button-pedestal.html` file contains a **fully self-contained floating SVG button on an art-deco pedestal** that drifts around the viewport with fairy-like motion. When pressed, the dome compresses, a shockwave + sparkle burst fires, and the page scrolls to the next section.

---

## How to integrate into `index.html`

### Step 1 — Copy the CSS

Paste these styles into your existing `<style>` block (anywhere after your existing rules):

```css
/* ── FLOATING PEDESTAL ── */
.pedestal-float {
  position: fixed;
  z-index: 50;
  pointer-events: none;
  width: 140px;
  height: 320px;
  filter: drop-shadow(0 20px 40px rgba(22,28,38,0.25))
          drop-shadow(0 4px 12px rgba(143,23,23,0.2));
  transition: filter 300ms ease;
}
.pedestal-float.pressed-glow {
  filter: drop-shadow(0 20px 40px rgba(22,28,38,0.25))
          drop-shadow(0 0 40px rgba(223,44,44,0.45))
          drop-shadow(0 4px 12px rgba(143,23,23,0.3));
}
.pedestal-float svg {
  width: 100%; height: 100%;
  pointer-events: auto;
  cursor: pointer;
}
.dome-group {
  transition: transform 100ms cubic-bezier(0.34, 1.56, 0.64, 1);
  transform-origin: 70px 68px;
}
.dome-group.pushed {
  transform: translateY(10px) scaleY(0.82);
}
.shockwave {
  position: fixed; pointer-events: none; z-index: 49;
  border-radius: 50%; border: 3px solid var(--red);
  opacity: 0; width: 40px; height: 40px;
}
.shockwave.go {
  animation: shockExpand 900ms cubic-bezier(0.22, 1, 0.36, 1) forwards;
}
@keyframes shockExpand {
  0% { transform: translate(-50%, -50%) scale(0.3); opacity: 0.7; }
  100% { transform: translate(-50%, -50%) scale(12); opacity: 0; }
}
.sparkle {
  position: fixed; pointer-events: none; z-index: 48;
  width: 6px; height: 6px; border-radius: 50%;
  background: var(--red-hot);
}
.sparkle.go { animation: sparkleFly 700ms ease-out forwards; }
@keyframes sparkleFly {
  0% { transform: translate(0, 0) scale(1); opacity: 1; }
  100% { transform: translate(var(--sx), var(--sy)) scale(0); opacity: 0; }
}
```

### Step 2 — Paste the HTML

Place this **right after `<body>`** (before `.shell`):

```html
<div class="shockwave" id="shockwave"></div>
```

Then paste the entire `<div class="pedestal-float" id="pedestalFloat">` block with its SVG inside — also right after `<body>`, before `.shell`. Copy it verbatim from the demo file.

### Step 3 — Add the Script

Paste the floating-button script **below your existing `<script>` block** (or merge them). The key parts:

```javascript
// ── FLOATING PEDESTAL SCRIPT ──
// (paste from the demo's <script> — the full animateFloat loop,
//  spawnSparkles function, and click handler)
```

### Step 4 — Configure Scroll Targets

In the demo, the scroll targets are:

```javascript
var scrollTargets = [
  document.getElementById("scrollTarget"),
  document.getElementById("scrollTarget2"),
  document.body
];
```

**Replace these** with your actual BRB page sections. For example:

```javascript
var scrollTargets = [
  document.querySelector(".lab-panel"),       // → Live Lab
  document.querySelector(".panel.reveal"),    // → Theoretical Framework
  document.querySelector(".methods-wrap"),    // → Methodological Framework
  document.querySelector(".footer"),          // → Footer
  document.body                               // → loop to top
];
```

### Step 5 — Hook into the existing press counter (optional)

Inside the pedestal click handler, add a line to also fire your existing button's logic:

```javascript
// After the shockwave + sparkles code:
document.getElementById("pressBtn").click();
// This triggers the waveform, entropy, interval, and burst visualizations
```

This way pressing the floating pedestal button ALSO counts as a research press.

---

## Tuning the Float Behavior

### Position

```javascript
var floatState = {
  baseX: 78,  // horizontal anchor (% of viewport width)
  baseY: 30,  // vertical anchor (% of viewport height)
  ...
};
```

Change `baseX` / `baseY` to reposition where the pedestal tends to hover.

### Drift intensity

```javascript
// Small continuous wobble amplitude (pixels)
var driftX = Math.sin(...) * 18 + Math.sin(...) * 10;  // ← change 18/10
var driftY = Math.cos(...) * 14 + Math.sin(...) * 8;   // ← change 14/8

// Rotation wobble (degrees)
s.rotation = Math.sin(...) * 4 + Math.sin(...) * 2.5;  // ← change 4/2.5
```

### Large shift frequency

```javascript
s.nextShift = 4000 + Math.random() * 7000;  // ms between big drifts
s.shiftTargetX = (Math.random() - 0.5) * 120;  // px range of shift
s.shiftTargetY = (Math.random() - 0.5) * 80;
```

Lower = more frequent, larger = wilder shifts.

### Speed

Change the `0.008` easing factor to make shifts snappier (0.02) or dreamier (0.004):

```javascript
s.shiftCurrentX += (s.shiftTargetX - s.shiftCurrentX) * 0.008;
```

---

## SVG Anatomy (for further customization)

```
viewBox="0 0 140 320"

├─ Ambient glow ellipse (red halo behind dome)
├─ BASE SLAB (wide bottom, ellipse top-face)
├─ LOWER RING (metallic band)
├─ SHAFT (fluted column, art-deco bands)
│   ├─ Fluted channel lines
│   └─ Decorative mid-bands
├─ UPPER RING / CAPITAL (top of column)
├─ BUTTON HOUSING (cradle)
├─ DOME SHADOW
└─ DOME GROUP #domeGroup (animated on press)
    ├─ Dome body (radial gradient, red)
    ├─ Equator ring
    ├─ Specular highlight
    ├─ Rim light arc
    └─ Gleam dots (animated pulse)
```

- **To change button color**: edit `#domeGrad` stops
- **To change pedestal color**: edit `#pedestalGrad` and `#ringGrad`
- **To change pedestal height**: adjust the y-coordinates in the shaft `<path>` and shift everything proportionally
- **To make the dome bigger**: increase the rx/ry of the dome `<ellipse>` and widen the housing

---

## Mobile Notes

The pedestal is 140×320px which works down to ~375px screens. On very small viewports you may want to:

```css
@media (max-width: 650px) {
  .pedestal-float {
    width: 100px;
    height: 230px;
  }
}
```

And adjust `baseX` / `baseY` to keep it from overlapping key content.
